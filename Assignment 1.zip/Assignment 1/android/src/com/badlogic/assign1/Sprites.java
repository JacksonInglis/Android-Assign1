package com.badlogic.assign1;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.Animation;

public class Sprites implements ApplicationListener {

    // Spritesheet data
    private static final int FRAME_COLS = 6;    // Number of columns
    private static final int FRAME_ROWS = 5;    // Number of rows
    private Texture walkSheet;                  // Texture to hold the spritesheet
    private TextureRegion[] walkFrames;         // Texture array for the frames
    private Animation walkAnimation;            // Animation object for the sprite
    private TextureRegion currentFrame;         // The current frame to display
    private float stateTime;                    // The time that the program has been running

    SpriteBatch spriteBatch;                    // Spritebatch for rendering

    @Override
    public void create() {
        // Load the spritesheet
        walkSheet = new Texture(Gdx.files.internal("C:\\Users\\plasm\\OneDrive\\Documents\\Android games development\\assignment 1 assets v2\\assignment 1 assets v2\\player\\moving.png"));

        // Generate a two dimensional array of TextureRegion by splitting the spritesheet into individual regions
        TextureRegion[][] temp = TextureRegion.split(walkSheet, walkSheet.getWidth() / FRAME_COLS, walkSheet.getHeight() / FRAME_ROWS);

        // Create a one dimensional array to hold the final TestureRegions
        walkFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];

        // Loop through the 2D array and transfer the TextureRegion to the one dimensional array
        int index = 0;
        for (int i = 0; i < FRAME_ROWS; i++) {
            for (int j = 0; j < FRAME_COLS; j++) {
                walkFrames[index++] = temp[i][j];
            }
        }

        // Drop the TextureRegions into a new Animation object and set the framerate. As the
        // duration is set to 0.033, we will get 30 frames per second.
        walkAnimation = new Animation(0.033f, walkFrames);

        // Initialise the stateTime, aka how long the program has been running for.
        stateTime = 0.0f;

        // Initialise spriteBatch so that we can use it.
        spriteBatch = new SpriteBatch();
    }

    @Override
    public void render() {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

        // Increase the time the game has been running by adding deltaTime (the time since the
        // last update).
        stateTime += Gdx.graphics.getDeltaTime();

        // Grabe the current frame from the animation. Note that we need to cast it to TextureRegion.
        currentFrame = (TextureRegion)walkAnimation.getKeyFrame(stateTime, true);

        // Draw the frame within a spritebatch.
        spriteBatch.begin();
        spriteBatch.draw(currentFrame,1,1);
        spriteBatch.end();
    }

    @Override
    public void dispose() {
        // dispose of all the native resources
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }
}