package com.badlogic.assign1;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.awt.Button;

public class ButtonCreate extends Button {
    float a;
    float b;
    float c;
    float d;
    Texture pause_button_texture;
    boolean pressed;
    public ButtonCreate(float a, float b, float c, float d, Texture pause_button_texture) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.pause_button_texture = pause_button_texture;
        pressed = false;
    }
    public void buttonpress(boolean Check, int buttonx, int buttony) {
        pressed = false;
        if (Check) {
            int h = Gdx.graphics.getHeight();
            if (buttonx >= a && buttonx <= a + c && h - buttony >= b && h - buttony <= b + d) {
                pressed = true;
            }
        }
    }

    public void draw(SpriteBatch Batch) {
        Batch.draw(pause_button_texture, a, b, c, d);
    }
}
