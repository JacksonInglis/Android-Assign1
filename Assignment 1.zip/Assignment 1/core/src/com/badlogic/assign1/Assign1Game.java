package com.badlogic.assign1;

import static com.badlogic.gdx.Gdx.graphics;

import static jdk.nashorn.internal.objects.Global.exit;
import static jdk.nashorn.internal.objects.Global.print;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


public class Assign1Game implements ApplicationListener {

	// Spritesheet data
	private static final int FRAME_COLS = 3;    // Number of columns
	private static final int FRAME_ROWS = 6;    // Number of rows
	private static final int Gr_Frame_Col = 5;
	private static final int Play_Frame_Rows = 4;
	private Texture walkSheet;                  // Texture to hold the spritesheet
	private Texture gr_walksheet;
	private TextureRegion[] walkFrames;         // Texture array for the frames
	private TextureRegion[] GR_WalkFrames;
	private Animation walkAnimation;            // Animation object for the sprite
	private Animation Gr_Walkanimation;
	private TextureRegion currentFrame;         // The current frame to display
	private TextureRegion GR_Currentframe;
	private float stateTime;                    // The time that the program has been running
	float x;
	float y;
	float w;
	float h;

	//Creating the x and y coordinates for player, ground enemy, and air enemy
	int Char_X = 1;
	int Char_Y = 1;
	int GR_X = 2000;
	int GR_Y = 1;
	int Missile_X = 800;
	int Missile_Y = 150;
	int Player_Loc_X;
	int Player_Loc_Y;

	//Variables used to create new sprites and functions for the enemy and player
	boolean GR_Dead = false;
	java.util.Timer timer = new Timer();
	private Texture gr_death;
	private Texture Player_Death;
	private TextureRegion[] Gr_Deathframes;
	private TextureRegion[] Player_Deathframes;
	private Animation Gr_deathanim;
	private Animation Player_Deathanim;
	private TextureRegion Gr_Curr_Deathframe;
	private TextureRegion Player_Curr_Deathframe;
	Random rand = new Random();
	boolean Player_Dead;
	private Texture Gr_Missile;


	SpriteBatch spriteBatch;
	SpriteBatch Gr_Spritebatch;
	SpriteBatch Gr_deathsprite;
	SpriteBatch Player_Deathsprite;
	SpriteBatch Gr_Projectile;

	public Assign1Game() {
	}

	@Override
	public void create() {
		float h = graphics.getHeight();
		float w = graphics.getWidth();


		// Load the spritesheet
		walkSheet = new Texture(Gdx.files.internal("moving.png"));
		gr_walksheet = new Texture(Gdx.files.internal("moving_gr.png"));
		gr_death = new Texture(Gdx.files.internal("dying_gr.png"));
		Player_Death = new Texture(Gdx.files.internal("dying.png"));
		Gr_Missile = new Texture(Gdx.files.internal("projectile_gr.png"));

		// Generate a two dimensional array of TextureRegion by splitting the spritesheet into individual regions
		TextureRegion[][] temp = TextureRegion.split(walkSheet, walkSheet.getWidth() / FRAME_COLS, walkSheet.getHeight() / FRAME_ROWS);
		TextureRegion[][] limited = TextureRegion.split(gr_walksheet, gr_walksheet.getWidth()/FRAME_ROWS, gr_walksheet.getHeight()/FRAME_COLS);
		TextureRegion[][] for_now = TextureRegion.split(gr_death, gr_death.getWidth()/FRAME_ROWS, gr_death.getHeight()/Gr_Frame_Col);
		TextureRegion[][] PDeath_temp = TextureRegion.split(Player_Death, Player_Death.getWidth()/Gr_Frame_Col, Player_Death.getHeight()/Play_Frame_Rows);

		// Create a one dimensional array to hold the final TestureRegions
		walkFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];
		GR_WalkFrames = new TextureRegion[FRAME_ROWS * FRAME_COLS];
		Gr_Deathframes = new TextureRegion[FRAME_ROWS * Gr_Frame_Col];
		Player_Deathframes = new TextureRegion[Gr_Frame_Col * Play_Frame_Rows];

		// Loop through the 2D array and transfer the TextureRegion to the one dimensional array
		int index = 0;
		for (int i = 0; i < FRAME_ROWS; i++) {
			for (int j = 0; j < FRAME_COLS; j++) {
				walkFrames[index++] = temp[i][j];
			}
		}
		int counter = 0;
		for (int row = 0; row < FRAME_COLS; row++) {
			for (int col = 0; col < FRAME_ROWS; col++) {
				GR_WalkFrames[counter++] = limited[row][col];
			}
		}
		int death_count = 0;
		for (int ro = 0; ro < Gr_Frame_Col; ro++) {
			for (int cols = 0; cols < FRAME_ROWS; cols++) {
				Gr_Deathframes[death_count++] = for_now[ro][cols];
			}
		}
		int play_death_count = 0;
		for (int pr= 0; pr < Play_Frame_Rows; pr++) {
			for (int pc = 0; pc < Gr_Frame_Col; pc++) {
				Player_Deathframes[play_death_count++] = PDeath_temp[pr][pc];
			}
		}


		// Drop the TextureRegions into a new Animation object and set the framerate. As the
		// duration is set to 0.033, we will get 30 frames per second.
		walkAnimation = new Animation(0.033f, walkFrames);
		Gr_Walkanimation = new Animation(0.033f, GR_WalkFrames);
		Gr_deathanim = new Animation(0.033f, Gr_Deathframes);
		Player_Deathanim = new Animation(0.033f, Player_Deathframes);

		// Initialise the stateTime, aka how long the program has been running for.
		stateTime = 0.0f;

		// Initialise spriteBatch so that we can use it.
		spriteBatch = new SpriteBatch();
		Gr_Spritebatch = new SpriteBatch();
		Gr_Projectile = new SpriteBatch();

	}

	@Override
	public void render() {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);

		player_move();
		gr_enemy_move();

		// Increase the time the game has been running by adding deltaTime (the time since the
		// last update).
		stateTime += graphics.getDeltaTime();

		// Grabe the current frame from the animation. Note that we need to cast it to TextureRegion.
		currentFrame = (TextureRegion)walkAnimation.getKeyFrame(stateTime, true);
		GR_Currentframe = (TextureRegion)Gr_Walkanimation.getKeyFrame(stateTime, true);
		Gr_Curr_Deathframe = (TextureRegion)Gr_deathanim.getKeyFrame(stateTime, false);
		Player_Curr_Deathframe = (TextureRegion)Player_Deathanim.getKeyFrame(stateTime, false);

		// Draw the frame within a spritebatch.
		spriteBatch.begin();
		spriteBatch.draw(currentFrame,Char_X,Char_Y);
		spriteBatch.end();


		Gr_Spawn();
		if (GR_X == Player_Loc_X) {
			GR_Dead = true;
		}
		if (GR_Dead == true) {
			Gr_Spritebatch.begin();
			Gr_Spritebatch.draw(Gr_Curr_Deathframe, GR_X, GR_Y);
			Gr_Spritebatch.end();
			timer.schedule(Gr_Spawn(), 0, 1000);
		}

		int Player_Overlap_X = (graphics.getWidth()/5)*2;
		if (GR_X > 0 && GR_X < Player_Overlap_X){
			gr_shoot();
		}

		if (Player_Dead == true) {
			spriteBatch.begin();
			spriteBatch.draw(this.Player_Curr_Deathframe, Char_X, Char_Y);
			spriteBatch.end();
			System.exit(0);
		}
	}

	private TimerTask Gr_Spawn() {
		Gr_Spritebatch.begin();
		Gr_Spritebatch.draw(GR_Currentframe,GR_X,GR_Y);
		Gr_Spritebatch.end();
		//Creating a Ground Enemy
		return null;
	}

	private void player_move() {
		boolean Player_Input = Gdx.input.isTouched();
		//boolean Player_Jump = Gdx.input.isButtonPressed();

		if (Player_Input == true) {
			Char_X += 10;
			Player_Loc_X = Char_X;
		}
		else {
			//If the screen is not clicked, the player returns back to the left of the screen
			Char_X -= 10;
			Player_Loc_X = Char_X;
			if (Char_X < 1) {
				Char_X = 1;
				//Stops the player from going off the screen
				Player_Loc_X = Char_X;
			}
		}
	}

	private void gr_enemy_move() {
		int randgen = rand.nextInt(20);
		GR_X -= 1;
		//Moves the enemy consistently to the left
		if (randgen == 2) {
			GR_X += 5;
			//Occasionally moves the enemy to the right to slow down its march
		}
	}

	private void gr_shoot() {
		//Is meant to create and move the missile towards the player
			Gr_Projectile.begin();
			Gr_Projectile.draw(Gr_Missile,Missile_X,Missile_Y);
			Gr_Projectile.end();
			Missile_X -= 15;
			if (Missile_X == Char_X) {

				Player_Dead = true;
			}
	}

	@Override
	public void dispose() {
		// dispose of all the native resources
		spriteBatch.dispose();
		Gr_Spritebatch.dispose();
		Player_Deathsprite.dispose();
		Gr_deathsprite.dispose();
		Gr_Projectile.dispose();
	}

	@Override
	public void resize(int width, int height) {
	}


	@Override
	public void pause() {

	}

	@Override
	public void resume() {
	}
}